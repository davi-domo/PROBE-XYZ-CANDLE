<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>frmMain</name>
    <message>
        <source>Test plugin 1</source>
        <translation>Тестовый плагин 1</translation>
    </message>   
    </context>
    <context>
    <name>Test1</name>
    <message>
        <source>Command:</source>
        <translation>Команда:</translation>
    </message>   
    <message>
        <source>Response:</source>
        <translation>Ответ:</translation>
    </message>   
</context>
</TS>